//
// Created by Taras Martynyuk on 3/9/18.
//
#ifndef INC_06TIME_MONTHUTILS_H
#define INC_06TIME_MONTHUTILS_H
#include <string>

std::string monthToName(int);
unsigned daysInMonth(int m, int y);


#endif //INC_06TIME_MONTHUTILS_H
