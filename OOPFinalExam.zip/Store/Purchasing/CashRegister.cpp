//
// Created by Taras Martynyuk on 5/2/2018.
//

#include "CashRegister.h"
