//
// Created by Taras Martynyuk on 5/1/2018.
//

#ifndef OOPFINALEXAM_TEST_H
#define OOPFINALEXAM_TEST_H

void run_all_tests();

#endif //OOPFINALEXAM_TEST_H
