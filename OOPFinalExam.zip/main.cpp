#include <iostream>
#include <chrono>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <vector>
#include <queue>
#include <cassert>
#include "test.h"
#include "test_utils.h"
using namespace std;

int main()
{
    run_all_tests();

    return 0;
}